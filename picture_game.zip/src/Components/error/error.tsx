const Error = () => {
  return (
    <div>
      <h1>404 PAGE NOT FOUND</h1>
    </div>
  );
};
export default Error;
