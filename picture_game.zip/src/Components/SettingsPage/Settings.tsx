// import styles from './SettingsStyle.module.scss'
import SettingsALL from "../../pages/settings/settingsH";
const Settings = () => {
  return (
    <div className="wrapper_settings">
      <SettingsALL />
    </div>
  );
};
export default Settings;
