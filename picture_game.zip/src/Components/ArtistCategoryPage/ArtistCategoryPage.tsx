import Body from "../../pages/artistCategoryPage/body/Body";
import Header from "../../pages/artistCategoryPage/header/header";
const ArtistCategoryPage = () => {
  return (
    <div className="wrapper_category">
      <Header />
      <Body />
    </div>
  );
};
export default ArtistCategoryPage;
