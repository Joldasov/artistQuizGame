import ArtistGamePageAll from "../../pages/artistGAMEPAGE/artistGamePage";

const ArtistGamePage = () => {
  return (
    <div className="wrapper_artistGamePage">
      <ArtistGamePageAll />
    </div>
  );
};
export default ArtistGamePage;
