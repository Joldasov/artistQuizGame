import PictureGamePage from "../../pages/pictureGamePage.tsx/pictureGamePage";

const PictureGame = () => {
  return (
    <div className="pictureGameWrapper">
      <PictureGamePage />
    </div>
  );
};

export default PictureGame;
